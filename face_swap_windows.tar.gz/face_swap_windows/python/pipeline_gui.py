"""
pipeline_gui.py
================

A simple Gradio/Flask dashboard for controlling a real‑time face‑swapping livestream
pipeline on Windows.  This script demonstrates how to launch face‑swap processes
(DeepFaceLive or roop‑cam), start a virtual camera, run Whisper for live
transcription and communicate with OBS via WebSocket.  It is meant as a
reference implementation rather than a polished product.

Prerequisites:
  * Python 3.9 (preferably inside a Conda environment).
  * DeepFaceLive installed and accessible via the `DEEPFACELIVE_PATH` environment
    variable.  Set this to the directory containing `main.py`.
  * Roop‑Cam installed and accessible via the `ROOPCAM_PATH` environment
    variable.  Set this to the directory containing `run.py` or the
    `run-cuda-windows.bat` script.
  * OBS installed with the `obs-websocket` plugin enabled.  Configure the
    WebSocket server in OBS (Tools → WebSockets Server Settings) and set the
    port and password below.
  * pyvirtualcam installed (pip install pyvirtualcam).
  * whisper installed (pip install git+https://github.com/openai/whisper.git).

Usage:

    conda activate faceswap
    python pipeline_gui.py

Open http://localhost:7860 in your browser to access the dashboard.

Note: This script is provided as a reference.  You may need to adapt paths and
OBS scene configuration to suit your environment.
"""

import os
import subprocess
import threading
import time
import sys
from pathlib import Path
from typing import Optional

try:
    import gradio as gr
except ImportError:
    print("Please install gradio: pip install gradio")
    sys.exit(1)

try:
    import whisper
except ImportError:
    whisper = None

try:
    import sounddevice as sd
    import numpy as np
except ImportError:
    sd = None
    np = None

try:
    import pyvirtualcam
except ImportError:
    pyvirtualcam = None

# -----------------------------------------------------------------------------
# Utility classes
# -----------------------------------------------------------------------------

class ProcessWrapper:
    """Small wrapper to manage subprocesses cleanly."""
    def __init__(self, cmd: list[str], cwd: Optional[str] = None, env: Optional[dict] = None):
        self.cmd = cmd
        self.cwd = cwd
        self.env = env or os.environ.copy()
        self.proc: Optional[subprocess.Popen] = None

    def start(self):
        """Launch the subprocess in the background."""
        if self.proc is not None:
            print(f"Process {self.cmd} already running")
            return
        print(f"Starting process: {' '.join(self.cmd)} in {self.cwd or os.getcwd()}")
        self.proc = subprocess.Popen(
            self.cmd,
            cwd=self.cwd,
            env=self.env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True,
        )
        # Start a thread to print output
        threading.Thread(target=self._stream_output, daemon=True).start()

    def _stream_output(self):
        assert self.proc is not None
        for line in self.proc.stdout:
            print(f"[{self.cmd[0]}] {line}", end="")

    def stop(self):
        """Terminate the subprocess if running."""
        if self.proc is not None:
            print(f"Terminating process: {' '.join(self.cmd)}")
            self.proc.terminate()
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                print("Process did not exit in time; killing")
                self.proc.kill()
            self.proc = None


class WhisperTranscriber(threading.Thread):
    """Captures microphone audio and transcribes it using whisper."""
    def __init__(self, model_name: str = "base", callback=None):
        super().__init__(daemon=True)
        self.model_name = model_name
        self.callback = callback
        self.stop_event = threading.Event()
        self.model = None

    def run(self):
        if whisper is None or sd is None or np is None:
            print("Whisper or sounddevice not installed; transcription disabled")
            return
        print(f"Loading Whisper model: {self.model_name}")
        self.model = whisper.load_model(self.model_name)
        sample_rate = 16000
        buffer = []

        def audio_callback(indata, frames, time_info, status):
            if self.stop_event.is_set():
                raise sd.CallbackStop()
            buffer.append(indata.copy())

        with sd.InputStream(samplerate=sample_rate, channels=1, callback=audio_callback):
            while not self.stop_event.is_set():
                time.sleep(5)
                # merge buffer and transcribe
                if buffer:
                    data = np.concatenate(buffer, axis=0)
                    buffer.clear()
                    print("Transcribing audio chunk...")
                    result = self.model.transcribe(data, fp16=False, language="en")
                    text = result.get("text", "").strip()
                    if text and self.callback:
                        self.callback(text)

    def stop(self):
        self.stop_event.set()


class FaceSwapController:
    """Manages launching of DeepFaceLive or roop-cam."""
    def __init__(self, method: str, source_face: Optional[Path], nsfw: bool):
        self.method = method
        self.source_face = source_face
        self.nsfw = nsfw
        self.process: Optional[ProcessWrapper] = None

    def start(self):
        env = os.environ.copy()
        # Set an example variable for NSFW toggle used by roop-cam; adjust as needed
        env["ALLOW_NSFW"] = "1" if self.nsfw else "0"

        if self.method == "DeepFaceLive":
            dfl_path = os.environ.get("DEEPFACELIVE_PATH")
            if not dfl_path:
                raise RuntimeError("DEEPFACELIVE_PATH environment variable is not set")
            cmd = [sys.executable, "main.py", "run", "DeepFaceLive"]
            # user data directory ensures models are stored in a user folder
            cmd += ["--user-data-dir", os.path.join(str(Path.home()), "DeepFaceLive")]
            self.process = ProcessWrapper(cmd, cwd=dfl_path, env=env)
        elif self.method == "Roop-Cam":
            roop_path = os.environ.get("ROOPCAM_PATH")
            if not roop_path:
                raise RuntimeError("ROOPCAM_PATH environment variable is not set")
            # If the batch file exists, use it, otherwise run via python
            bat_file = Path(roop_path) / "run-cuda-windows.bat"
            if bat_file.exists():
                cmd = [str(bat_file)]
            else:
                cmd = [sys.executable, "run.py"]
                # pass the source face if provided
                if self.source_face:
                    cmd += ["--source", str(self.source_face)]
                cmd += ["--execution-provider", "cuda"]
            self.process = ProcessWrapper(cmd, cwd=roop_path, env=env)
        else:
            raise ValueError(f"Unknown method {self.method}")
        self.process.start()

    def stop(self):
        if self.process:
            self.process.stop()


class VirtualCamera:
    """Starts a pyvirtualcam session and displays dummy frames."""
    def __init__(self, width=640, height=480, fps=30):
        self.width = width
        self.height = height
        self.fps = fps
        self.cam = None
        self.running = False

    def start(self):
        if pyvirtualcam is None:
            print("pyvirtualcam not installed; virtual camera disabled")
            return
        self.cam = pyvirtualcam.Camera(width=self.width, height=self.height, fps=self.fps, print_fps=True)
        self.running = True
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        import numpy as np  # local import to avoid global requirement if unused
        while self.running:
            # Here you would fetch frames from the face‑swap process and send to the virtual cam.
            # We send a dummy gray frame for demonstration.
            frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)
            self.cam.send(frame)
            self.cam.sleep_until_next_frame()

    def stop(self):
        self.running = False
        if self.cam:
            self.cam.close()


# -----------------------------------------------------------------------------
# Gradio Interface
# -----------------------------------------------------------------------------

class Dashboard:
    def __init__(self):
        self.face_controller: Optional[FaceSwapController] = None
        self.transcriber: Optional[WhisperTranscriber] = None
        self.virtual_cam = VirtualCamera()
        self.captions_history = []

    # Callbacks for gradio UI
    def start_stream(self, method: str, source_face, nsfw: bool, enable_transcription: bool):
        """Start the face‑swap process and transcription."""
        # Save uploaded face to a file if provided
        source_path = None
        if source_face is not None:
            filename = Path("uploads") / Path(source_face.name).name
            filename.parent.mkdir(exist_ok=True)
            with open(filename, "wb") as f:
                f.write(source_face.read())
            source_path = filename

        # Start face swap
        self.face_controller = FaceSwapController(method, source_path, nsfw)
        try:
            self.face_controller.start()
        except Exception as e:
            return f"Failed to start face swapping: {e}", ""

        # Start virtual camera
        self.virtual_cam.start()

        # Start whisper transcription
        if enable_transcription:
            self.transcriber = WhisperTranscriber(model_name="base", callback=self._on_caption)
            self.transcriber.start()
        return "Streaming started. Check your virtual camera in OBS.", ""

    def stop_stream(self):
        """Stop all running processes."""
        if self.face_controller:
            self.face_controller.stop()
            self.face_controller = None
        if self.transcriber:
            self.transcriber.stop()
            self.transcriber = None
        self.virtual_cam.stop()
        self.captions_history.clear()
        return "Streaming stopped.", ""

    def _on_caption(self, text: str):
        print(f"Whisper caption: {text}")
        self.captions_history.append(text)

    def get_captions(self):
        return "\n".join(self.captions_history[-20:])

    def build_ui(self):
        with gr.Blocks(title="FaceSwap Dashboard") as demo:
            gr.Markdown("# FaceSwap Livestream Dashboard")
            gr.Markdown(
                "Select a face‑swapping backend, upload a source face (optional for roop), toggle NSFW mode and transcription, then click **Start Stream**."
            )
            with gr.Row():
                method = gr.Dropdown(["DeepFaceLive", "Roop-Cam"], value="DeepFaceLive", label="Face‑Swap Method")
                nsfw = gr.Checkbox(value=False, label="Enable NSFW models")
                transcription = gr.Checkbox(value=True, label="Enable Whisper Captions")
            source_face = gr.File(label="Upload source face (optional)")
            start_btn = gr.Button("Start Stream")
            stop_btn = gr.Button("Stop Stream")
            status = gr.Textbox(label="Status", interactive=False)
            captions = gr.Textbox(label="Live Captions", interactive=False)

            start_btn.click(self.start_stream, inputs=[method, source_face, nsfw, transcription], outputs=[status, captions])
            stop_btn.click(self.stop_stream, inputs=None, outputs=[status, captions])

            # Periodically update captions
            gr.Timer(1.0, self.get_captions, None, outputs=captions)
        return demo


def main():
    dashboard = Dashboard()
    ui = dashboard.build_ui()
    ui.launch()


if __name__ == "__main__":
    main()